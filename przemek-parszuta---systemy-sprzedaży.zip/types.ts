
export interface Testimonial {
  n: string;
  r: string;
  q: string;
}
