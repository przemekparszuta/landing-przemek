
import React, { useEffect, useState } from 'react';

const LandingPage: React.FC = () => {
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.15 });

    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const contactLinks = {
    messenger: "https://m.me/przemyslawparszuta",
    whatsapp: "https://wa.me/48729615263",
    calendar: "https://calendar.app.google/KxiKXmK6J4DXRJZN7",
    phone: "tel:+48729615263",
    email: "mailto:przemekparszuta@gmail.com",
    facebook: "https://www.facebook.com/przemekparszuta",
    instagram: "https://www.instagram.com/przemek.parszuta/",
    linkedin: "https://www.linkedin.com/in/przemys%C5%82aw-parszuta/",
    reviews: "https://www.google.com/search?q=Przemek+Parszuta-+Reklama+Facebook+i+Social+Media+Biskupiec+Opinie"
  };

  const fileId = "1htJNRzUJYiY7yXCDz0p_-2zKpOxENlIU";
  const userPhoto = `https://drive.google.com/thumbnail?id=${fileId}&sz=w1200`;

  const testimonials = [
    { 
      n: "Modul Haus", 
      r: "Szybka komunikacja", 
      q: "Przemek to osoba, z którą współpraca to przyjemność. Wielkim plusem jest to, że bardzo szybko odpowiada na wiadomości i nie ma problemu z kontaktem. Zawsze coś doradzi i jest osobą kompetentną." 
    },
    { 
      n: "Lewtak Ciesielstwo", 
      r: "Indywidualne podejście", 
      q: "Do każdego klienta Przemek podchodzi indywidualnie. Kontakt jak z dobrym kumplem. Można pogadać o wszystkim a nie tylko o współpracy. Ceni się to, że nie czeka się pół dnia na odpowiedź w razie pytań. Widać że cały czas się rozwija i poszerza wiedzę z zakresu marketingu." 
    },
    { 
      n: "TM Bud", 
      r: "Odpowiedzialność", 
      q: "Współpraca z Przemkiem jak najbardziej na tak. Pomógł mi w kilku kwestiach. Jest odpowiedzialną, kompetentną i słowną osobą. Jeżeli będę potrzebował pomocy w kwestii reklamy lub marketingu ponownie. Na pewno się zgłoszę." 
    },
    { 
      n: "Modern Paradise", 
      r: "Wartość dodana", 
      q: "Szczerze można polecić usługi Przemka. Jest osobą, która wkłada do współpracy wartość i zawsze można liczyć na pomoc, nawet jeśli nie ma tego w umowie. Widać że lubi tą robotę, no i plusem jest fakt, że jeśli pojawią się jakieś nowości w świecie marketingów to Przemek już poszerza swoją wiedzę. Mogę śmiało polecić." 
    }
  ];

  return (
    <div className="relative min-h-screen bg-white text-black selection:bg-yellow-100 overflow-x-hidden">
      {/* Background Accents */}
      <div className="fixed inset-0 z-[-1] hero-gradient opacity-40"></div>

      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-white/90 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 md:h-20 flex items-center justify-between">
          <div className="text-sm md:text-xl tracking-tight flex items-center">
            <span className="font-light uppercase tracking-[0.2em] md:tracking-[0.25em] text-slate-400">PRZEMEK</span>
            <span className="font-black ml-1.5 md:ml-2 uppercase tracking-tight text-black">PARSZUTA</span>
          </div>
          <div className="hidden lg:flex space-x-10 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">
            <a href="#problem" className="hover:text-yellow-600 transition-colors">Problem</a>
            <a href="#proces" className="hover:text-yellow-600 transition-colors">Proces</a>
            <a href="#gwarancja" className="hover:text-yellow-600 transition-colors">Gwarancja</a>
            <a href="#opinie" className="hover:text-yellow-600 transition-colors">Opinie</a>
            <a href="#inwestycja" className="hover:text-yellow-600 transition-colors">Cennik</a>
          </div>
          <div className="flex items-center">
            <a href={contactLinks.calendar} target="_blank" className="px-4 py-2 md:px-7 md:py-3 bg-black text-white rounded-xl text-[9px] md:text-[10px] font-bold uppercase tracking-widest hover:bg-yellow-400 hover:text-black transition-all duration-300 shadow-xl shadow-black/10">
              Konsultacja
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-4 md:px-6">
        <div className="max-w-6xl mx-auto text-center">
          <div className="reveal">
            <span className="inline-block px-4 py-1.5 md:px-5 md:py-2 rounded-full border border-yellow-200 bg-yellow-50 text-yellow-700 text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] md:tracking-[0.3em] mb-6 md:mb-10 shadow-sm">
              90-dniowa Transformacja Sprzedaży
            </span>
          </div>
          
          <h1 className="text-3xl sm:text-4xl md:text-7xl lg:text-8xl mb-8 md:mb-12 leading-[1.1] md:leading-[1.05] reveal delay-100 px-2">
            <span className="font-extralight block text-slate-400 tracking-tight">Budujesz domy za setki tysięcy.</span>
            <span className="font-black mt-2 block text-black">
              Sprzedaż <span className="yellow-underline">nie może wyglądać</span> jak plac budowy po burzy.
            </span>
          </h1>

          <p className="text-base md:text-2xl text-slate-500 mb-10 md:mb-16 max-w-4xl mx-auto leading-relaxed reveal delay-200 px-4">
            Pomagam firmom budującym domy <span className="text-black font-semibold">uporządkować sprzedaż</span> i uruchomić stały dopływ kwalifikowanych zapytań w 90 dni.
            <span className="block mt-4 md:mt-6 text-black font-medium italic">Najpierw porządek. Potem dopiero gaz.</span>
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center items-center gap-4 md:gap-6 reveal delay-300">
            <a href={contactLinks.calendar} target="_blank" className="w-full sm:w-auto group relative px-8 py-5 md:px-14 md:py-6 bg-black text-white rounded-2xl text-base md:text-lg font-bold overflow-hidden transition-all hover:scale-105 shadow-2xl shadow-black/10 text-center">
              <span className="relative z-10">🔘 Umów rozmowę</span>
              <div className="absolute inset-0 bg-yellow-400 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
            </a>
            <div className="flex space-x-4">
              <a href={contactLinks.messenger} target="_blank" className="p-4 md:p-5 bg-white border border-slate-100 rounded-2xl hover:border-yellow-400 hover:shadow-lg transition-all">
                <img src="https://upload.wikimedia.org/wikipedia/commons/b/be/Facebook_Messenger_logo_2020.svg" className="w-6 h-6 md:w-7 md:h-7" alt="Messenger" />
              </a>
              <a href={contactLinks.whatsapp} target="_blank" className="p-4 md:p-5 bg-white border border-slate-100 rounded-2xl hover:border-yellow-400 hover:shadow-lg transition-all">
                <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" className="w-6 h-6 md:w-7 md:h-7" alt="WhatsApp" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section with User Photo */}
      <section id="problem" className="py-20 md:py-32 px-4 md:px-6 bg-slate-50/30 overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 md:gap-24 items-center">
            <div className="reveal">
              <h2 className="text-3xl md:text-6xl mb-8 md:mb-12">
                <span className="font-extralight block text-slate-400">Większość firm</span>
                <span className="font-black block">ma problem z:</span>
              </h2>
              <div className="space-y-6 md:space-y-8 text-lg md:text-xl text-slate-600">
                {[
                  "kontaktami w kilku miejscach",
                  "brakiem jasnych etapów obsługi",
                  "zapytaniami „do oddzwonienia”",
                  "reklamą, która budzi stres zamiast spokoju"
                ].map((item, i) => (
                  <div key={i} className="flex items-start group">
                    <span className="text-yellow-500 mr-4 md:mr-5 font-black text-xl md:text-2xl">—</span>
                    <span className="font-light group-hover:text-black transition-colors">{item}</span>
                  </div>
                ))}
              </div>
              <div className="mt-12 md:mt-20 p-8 md:p-12 bg-white border-l-8 border-yellow-400 shadow-xl md:shadow-2xl shadow-slate-200/50 rounded-r-2xl md:rounded-r-3xl reveal">
                <p className="text-xl md:text-2xl font-light italic text-slate-800 leading-relaxed">
                  "Reklama bez systemu to jak <span className="font-bold underline decoration-yellow-400 decoration-4">dolewanie betonu do krzywej formy</span>. Niby się nie wyleje. Ale nie będzie prosto."
                </p>
              </div>
            </div>
            
            <div className="relative reveal delay-200 flex justify-center lg:justify-end min-h-[350px] md:min-h-[500px]">
              <div className="absolute -inset-10 md:-inset-20 bg-yellow-200/20 rounded-full blur-[80px] md:blur-[120px] opacity-60"></div>
              
              <div className="relative max-w-xs md:max-w-lg w-full z-10 flex items-end">
                {!imgError ? (
                  <img 
                    src={userPhoto} 
                    alt="Przemysław Parszuta" 
                    className="w-full h-auto object-contain max-h-[500px] md:max-h-[800px] drop-shadow-[0_15px_40px_rgba(0,0,0,0.15)] transition-all duration-500 hover:drop-shadow-[0_25px_60px_rgba(0,0,0,0.25)]" 
                    onError={() => setImgError(true)}
                  />
                ) : (
                  <div className="w-full aspect-[4/5] bg-white/50 backdrop-blur-sm rounded-[2rem] md:rounded-[3rem] flex items-center justify-center border-2 border-dashed border-slate-200">
                    <div className="text-center p-6 md:p-10">
                      <div className="text-4xl md:text-5xl mb-4 md:mb-6 opacity-30">👤</div>
                      <p className="text-slate-400 text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] leading-loose">
                        Zdjęcie w procesie<br/>weryfikacji
                      </p>
                    </div>
                  </div>
                )}
              </div>

              <div className="absolute bottom-5 md:bottom-10 right-0 p-6 md:p-10 bg-black/95 backdrop-blur-md text-white rounded-[1.5rem] md:rounded-[2.5rem] shadow-2xl max-w-[180px] md:max-w-[260px] z-20 border border-white/10 scale-90 md:scale-100 origin-bottom-right">
                <div className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.3em] text-yellow-400 mb-2 md:mb-4">Ekspert Systemów</div>
                <div className="text-xl md:text-2xl font-black leading-tight italic">Przemysław Parszuta.</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="py-24 md:py-40 px-4 md:px-6">
        <div className="max-w-4xl mx-auto text-center reveal">
          <h2 className="text-[9px] md:text-[10px] font-black text-yellow-600 uppercase tracking-[0.3em] md:tracking-[0.4em] mb-8 md:mb-12">Filozofia Pracy</h2>
          <p className="text-2xl md:text-5xl font-extralight leading-[1.3] md:leading-[1.4] text-slate-900 mb-8 md:mb-10">
            Nie dokładam zapytań do bałaganu. <br className="hidden md:block"/><br className="hidden md:block"/>
            Najpierw budujemy <span className="font-black yellow-underline">fundament sprzedaży</span>. <br className="hidden md:block"/>
            Potem dopiero zwiększamy ruch.
          </p>
          <div className="h-px w-16 md:w-24 bg-slate-200 mx-auto mb-8 md:mb-10"></div>
          <p className="text-xl md:text-2xl text-slate-400 font-light italic">
            Bo wzrost bez kontroli to nie rozwój. <span className="text-black font-bold">To przeciążenie.</span>
          </p>
        </div>
      </section>

      {/* 90 Days Roadmap */}
      <section id="proces" className="py-20 md:py-32 px-4 md:px-6 bg-slate-50/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 md:mb-24 reveal">
            <h2 className="text-[9px] md:text-[10px] font-black text-yellow-600 uppercase tracking-[0.3em] md:tracking-[0.4em] mb-4 md:mb-6">Proces 90 Dni</h2>
            <div className="text-3xl md:text-6xl mb-6 md:mb-8">
              <span className="font-extralight">Plan, który</span> <span className="font-black">dowozi wyniki.</span>
            </div>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 md:gap-10">
            {[
              { m: "01", t: "Kontrola", items: ["Wszystkie kontakty w jednym miejscu", "Jasne etapy obsługi", "System przypomnień"], d: "Bez Excela. Bez zeszytu. Bez „mam to w głowie”. Efekt: Wiesz dokładnie, co się dzieje." },
              { m: "02", t: "Zapytania", items: ["Kampania reklamowa", "Filtrujący formularz", "Oddzielanie ciekawskich"], d: "Nie każdy, kto kliknie „interesuje mnie budowa domu”, jest klientem. System oddziela konkret od szumu." },
              { m: "03", t: "Umowy", items: ["Usprawniamy rozmowy", "Analiza liczb", "Optymalizacja kampanii"], d: "Bo sprzedaż to nie magia. To proces oparty na danych i powtarzalnych działaniach." }
            ].map((step, idx) => (
              <div key={idx} className="group p-8 md:p-12 bg-white rounded-[2rem] md:rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-500 reveal relative" style={{ transitionDelay: `${idx * 0.2}s` }}>
                <div className="text-6xl md:text-8xl font-black text-slate-50 group-hover:text-yellow-50 transition-colors absolute top-6 right-6 md:top-10 md:right-10 z-0 select-none">{step.m}</div>
                <h3 className="text-2xl md:text-3xl font-black text-black mb-6 md:mb-8 relative z-10">{step.t}</h3>
                <ul className="space-y-3 md:space-y-4 mb-8 md:mb-10 relative z-10">
                  {step.items.map((li, i) => (
                    <li key={i} className="flex items-start text-slate-600 font-light text-sm md:text-base">
                      <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-3 mt-1.5 flex-shrink-0"></div>
                      <span>{li}</span>
                    </li>
                  ))}
                </ul>
                <p className="text-slate-400 text-xs md:text-sm leading-relaxed italic relative z-10">{step.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="opinie" className="py-20 md:py-32 px-4 md:px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 md:mb-24 reveal">
            <h2 className="text-[9px] md:text-[10px] font-black text-yellow-600 uppercase tracking-[0.3em] md:tracking-[0.4em] mb-4 md:mb-6">Zadowoleni Partnerzy</h2>
            <div className="text-3xl md:text-5xl mb-4 md:mb-6 leading-tight">
              <span className="font-extralight">Klienci o</span> <span className="font-black">współpracy.</span>
            </div>
            <div className="flex justify-center space-x-1 mb-3">
              {[1, 2, 3, 4, 5].map(s => (
                <svg key={s} className="w-4 h-4 md:w-5 md:h-5 text-yellow-400 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3-.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
              ))}
            </div>
            <a href={contactLinks.reviews} target="_blank" className="text-[9px] md:text-xs font-bold text-slate-400 hover:text-black uppercase tracking-widest transition-colors">Opinie Google ⭐⭐⭐⭐⭐</a>
          </div>

          <div className="grid md:grid-cols-2 gap-6 md:gap-8">
            {testimonials.map((testi, i) => (
              <div key={i} className="p-8 md:p-12 bg-slate-50 rounded-[2rem] md:rounded-[3rem] border border-slate-100 flex flex-col justify-between reveal transition-all hover:bg-white hover:shadow-xl md:hover:shadow-2xl hover:shadow-slate-200/50" style={{ transitionDelay: `${i * 0.15}s` }}>
                <div className="mb-6 md:mb-10">
                  <p className="text-base md:text-xl font-light italic text-slate-800 leading-relaxed">"{testi.q}"</p>
                </div>
                <div className="flex items-center pt-6 md:pt-8 border-t border-slate-200/50">
                  <div className="w-10 h-10 md:w-12 md:h-12 bg-black text-white rounded-full flex items-center justify-center font-black text-xs md:text-sm mr-4 md:mr-5">
                    {testi.n[0]}
                  </div>
                  <div>
                    <div className="font-black text-black text-base md:text-lg tracking-tight">{testi.n}</div>
                    <div className="text-[9px] md:text-xs font-bold text-yellow-600 uppercase tracking-widest">{testi.r}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Guarantee Section */}
      <section id="gwarancja" className="py-20 md:py-32 px-4 md:px-6">
        <div className="max-w-6xl mx-auto bg-black rounded-[2.5rem] md:rounded-[4rem] p-10 md:p-32 text-white relative overflow-hidden reveal">
          <div className="absolute top-0 right-0 w-2/3 h-full bg-gradient-to-l from-yellow-500/10 to-transparent"></div>
          <div className="relative z-10">
            <h2 className="text-[10px] font-black text-yellow-400 uppercase tracking-[0.4em] md:tracking-[0.5em] mb-8 md:mb-12">Gwarancja Wyniku</h2>
            <h3 className="text-2xl md:text-7xl font-extralight mb-8 md:mb-12 leading-tight md:leading-tight">
              Minimum <span className="font-black text-yellow-400 italic">5 kwalifikowanych zapytań</span> od realnych klientów.
            </h3>
            <div className="max-w-2xl space-y-6 md:space-y-10 text-base md:text-xl text-slate-400 font-light leading-relaxed mb-10 md:mb-16">
              <p>Jeśli po 90 dniach nie osiągniemy tego poziomu, pracuję dalej w modelu optymalizacyjnym za <span className="text-white font-bold underline decoration-yellow-400 decoration-2 underline-offset-8">1000 zł miesięcznie</span>, aż dowieziemy wynik.</p>
            </div>
            <a href={contactLinks.calendar} target="_blank" className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-5 md:px-12 md:py-6 bg-yellow-400 text-black rounded-2xl font-black text-lg md:text-xl hover:scale-105 transition-transform shadow-2xl shadow-yellow-400/20">
              🔘 Umów rozmowę
            </a>
          </div>
        </div>
      </section>

      {/* Investment Section */}
      <section id="inwestycja" className="py-24 md:py-40 px-4 md:px-6 bg-slate-50/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 md:mb-24 reveal">
            <h2 className="text-[9px] md:text-[10px] font-black text-yellow-600 uppercase tracking-[0.3em] md:tracking-[0.4em] mb-4 md:mb-6">Warunki Współpracy</h2>
            <div className="text-3xl md:text-6xl leading-tight">
              <span className="font-extralight">Twoja inwestycja w</span> <span className="font-black">system.</span>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 md:gap-12">
            <div className="p-10 md:p-16 bg-white rounded-[2.5rem] md:rounded-[4rem] border border-slate-100 flex flex-col reveal shadow-sm hover:shadow-2xl transition-all duration-500">
              <div className="mb-8 md:mb-12">
                <span className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] md:tracking-[0.3em] text-slate-400 mb-6 md:mb-8 block">Etap Wdrożenia</span>
                <h3 className="text-2xl md:text-4xl font-black text-black mb-8 md:mb-10">Program 90 dni</h3>
                <div className="flex items-baseline mb-8 md:mb-12">
                  <span className="text-5xl md:text-7xl font-black">15 000</span>
                  <span className="text-lg md:text-2xl font-light ml-3 md:ml-4 opacity-30 tracking-widest">PLN</span>
                </div>
                <div className="space-y-4 md:space-y-6 text-slate-600 font-light text-sm md:text-base">
                  <div className="flex items-start"><div className="w-4 h-4 md:w-5 md:h-5 bg-yellow-400 rounded-full mr-4 md:mr-5 mt-1 flex-shrink-0"></div> <span>Uporządkowanie obecnej bazy i procesów</span></div>
                  <div className="flex items-start"><div className="w-4 h-4 md:w-5 md:h-5 bg-yellow-400 rounded-full mr-4 md:mr-5 mt-1 flex-shrink-0"></div> <span>Zaprojektowanie lejków pod budowę domów</span></div>
                  <div className="flex items-start"><div className="w-4 h-4 md:w-5 md:h-5 bg-yellow-400 rounded-full mr-4 md:mr-5 mt-1 flex-shrink-0"></div> <span>Wdrażanie kampanii i analityki sprzedaży</span></div>
                  <div className="mt-8 md:mt-10 p-4 md:p-6 bg-black text-white rounded-2xl font-black uppercase tracking-widest text-[9px] md:text-xs text-center">Płatność z góry</div>
                </div>
              </div>
              <a href={contactLinks.calendar} target="_blank" className="mt-auto py-5 md:py-6 bg-yellow-400 text-black text-center rounded-2xl font-black uppercase tracking-widest text-[10px] md:text-sm hover:scale-105 transition-all shadow-xl shadow-yellow-400/10">
                Umów Rozmowę
              </a>
            </div>
            
            <div className="p-10 md:p-16 bg-black rounded-[2.5rem] md:rounded-[4rem] flex flex-col text-white reveal shadow-2xl transition-all duration-500" style={{ transitionDelay: '0.2s' }}>
              <div className="mb-8 md:mb-12">
                <span className="text-[9px] md:text-[10px] font-black uppercase tracking-[0.2em] md:tracking-[0.3em] text-yellow-400 mb-6 md:mb-8 block">Długofalowy Wzrost</span>
                <h3 className="text-2xl md:text-4xl font-black mb-8 md:mb-10">Stała Opieka</h3>
                <div className="flex items-baseline mb-8 md:mb-12">
                  <span className="text-5xl md:text-7xl font-black text-yellow-400">3 000</span>
                  <span className="text-lg md:text-2xl font-light ml-3 md:ml-4 opacity-40 tracking-widest">PLN / MIES.</span>
                </div>
                <div className="space-y-6 md:space-y-8 text-slate-400 font-light leading-relaxed text-sm md:text-base">
                  <p>Stałe dbanie o system, optymalizacja kosztów leada i skalowanie wyników.</p>
                  <div className="p-6 md:p-8 bg-white/5 rounded-2xl md:rounded-3xl border border-white/10">
                    <p className="text-xs md:text-sm">Po rozmowie jest też możliwy <span className="text-yellow-400 font-bold underline underline-offset-4">pakiet bardziej dopasowany</span> pod Twoje potrzeby.</p>
                  </div>
                </div>
              </div>
              <p className="mt-auto text-center text-[8px] md:text-[10px] font-bold text-slate-500 uppercase tracking-widest">Gwarancja wyłączności w regionie.</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 md:py-32 px-4 md:px-6 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-[9px] md:text-[10px] font-black text-yellow-600 uppercase tracking-[0.3em] md:tracking-[0.4em] text-center mb-10 md:mb-16 reveal">Częste Pytania</h2>
          <div className="space-y-4">
            {[
              { q: "Dlaczego tylko branża budowy domów?", a: "Ponieważ w tej niszy mam wypracowane konkretne procesy, które dowożą najwyższe zwroty z inwestycji. Rozumiem klienta, który buduje dom." },
              { q: "Co jeśli mam już marketing?", a: "Program 90 dni to nie tylko marketing, to przebudowa fundamentów sprzedaży. Najpierw sprawdzamy czy to, co masz obecnie, nie przepala Twoich pieniędzy." },
              { q: "Jak wygląda rozmowa kwalifikacyjna?", a: "Wybierasz termin w kalendarzu, rozmawiamy 15 minut o Twojej firmie. Jeśli widzę, że mogę pomóc – przedstawiam plan. Jeśli nie – powiem Ci to od razu." },
              { q: "Czy budżet reklamowy jest w cenie?", a: "Nie, budżet reklamowy jest po stronie Twojej firmy. Ja dostarczam kompletny system, który te pieniądze zamienia w kwalifikowane zapytania." }
            ].map((item, idx) => (
              <details key={idx} className="group bg-slate-50 rounded-2xl md:rounded-3xl border border-slate-100 reveal overflow-hidden" style={{ transitionDelay: `${idx * 0.1}s` }}>
                <summary className="flex items-center justify-between p-6 md:p-10 cursor-pointer list-none">
                  <span className="text-base md:text-lg font-bold group-open:text-yellow-600 transition-colors pr-6">{item.q}</span>
                  <span className="text-2xl md:text-3xl font-extralight group-open:rotate-45 transition-transform">+</span>
                </summary>
                <div className="px-6 pb-6 md:px-10 md:pb-10 text-slate-500 font-light text-sm md:text-base leading-relaxed border-t border-white pt-6 md:pt-8">
                  {item.a}
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 md:py-32 px-4 md:px-6 border-t border-slate-100 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-4 gap-12 lg:gap-20 mb-16 md:mb-20">
            <div className="col-span-2">
              <div className="text-xl md:text-3xl mb-6 md:mb-8 flex items-center">
                <span className="font-extralight uppercase tracking-[0.2em]">PRZEMEK</span>
                <span className="font-bold ml-1.5 uppercase tracking-tighter">PARSZUTA</span>
              </div>
              <p className="text-slate-500 max-w-sm mb-10 md:mb-12 font-light leading-relaxed text-sm md:text-base">
                Transformuję chaos w przewidywalne zyski. Architekt systemów sprzedaży dla profesjonalnych firm budowlanych.
              </p>
              <div className="flex flex-wrap gap-6 md:space-x-10">
                <a href={contactLinks.facebook} target="_blank" className="text-slate-400 hover:text-black transition-colors font-bold uppercase text-[9px] md:text-[10px] tracking-[0.2em] md:tracking-[0.3em]">Facebook</a>
                <a href={contactLinks.instagram} target="_blank" className="text-slate-400 hover:text-black transition-colors font-bold uppercase text-[9px] md:text-[10px] tracking-[0.2em] md:tracking-[0.3em]">Instagram</a>
                <a href={contactLinks.linkedin} target="_blank" className="text-slate-400 hover:text-black transition-colors font-bold uppercase text-[9px] md:text-[10px] tracking-[0.2em] md:tracking-[0.3em]">LinkedIn</a>
              </div>
            </div>
            <div>
              <h4 className="font-bold text-[9px] md:text-[10px] uppercase tracking-[0.2em] text-yellow-600 mb-8 md:mb-10">Kontakt</h4>
              <div className="space-y-6 md:space-y-8">
                <div>
                  <div className="text-[9px] md:text-[10px] font-black text-slate-300 uppercase mb-2">Telefon</div>
                  <a href={contactLinks.phone} className="block text-xl md:text-2xl font-light hover:text-yellow-600 transition-colors tracking-tighter">729 615 263</a>
                </div>
                <div>
                  <div className="text-[9px] md:text-[10px] font-black text-slate-300 uppercase mb-2">Email</div>
                  <a href={contactLinks.email} className="block text-xs md:text-sm font-medium text-slate-500 hover:text-black">przemekparszuta@gmail.com</a>
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-bold text-[9px] md:text-[10px] uppercase tracking-[0.2em] text-yellow-600 mb-8 md:mb-10">Linki</h4>
              <div className="space-y-4 md:space-y-6 text-xs md:text-sm font-medium text-slate-500">
                <a href={contactLinks.calendar} target="_blank" className="flex items-center hover:text-black group">
                  <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-3 group-hover:scale-150 transition-transform"></div>
                  Kalendarz Google
                </a>
                <a href={contactLinks.reviews} target="_blank" className="flex items-center hover:text-black group">
                  <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full mr-3 group-hover:scale-150 transition-transform"></div>
                  Opinie Google
                </a>
              </div>
            </div>
          </div>
          <div className="pt-10 md:pt-12 border-t border-slate-50 flex flex-col md:flex-row justify-between items-center text-[8px] md:text-[9px] text-slate-400 font-bold uppercase tracking-[0.3em] md:tracking-[0.4em] text-center md:text-left gap-4">
            <div>© {new Date().getFullYear()} Przemysław Parszuta — Wszystkie prawa zastrzeżone</div>
            <div className="opacity-50">Precision • Order • Growth</div>
          </div>
        </div>
      </footer>

      {/* Floating Buttons */}
      <div className="fixed bottom-6 right-6 md:bottom-10 md:right-10 z-[100] flex flex-col space-y-3 md:space-y-4">
        <a href={contactLinks.whatsapp} target="_blank" title="WhatsApp" className="w-12 h-12 md:w-14 md:h-14 bg-white border border-slate-100 shadow-2xl rounded-full flex items-center justify-center hover:scale-110 transition-all group">
          <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" className="w-5 h-5 md:w-6 md:h-6 grayscale group-hover:grayscale-0 transition-all" alt="WhatsApp" />
        </a>
        <a href={contactLinks.messenger} target="_blank" title="Messenger" className="w-12 h-12 md:w-14 md:h-14 bg-white border border-slate-100 shadow-2xl rounded-full flex items-center justify-center hover:scale-110 transition-all group">
          <img src="https://upload.wikimedia.org/wikipedia/commons/b/be/Facebook_Messenger_logo_2020.svg" className="w-5 h-5 md:w-6 md:h-6 grayscale group-hover:grayscale-0 transition-all" alt="Messenger" />
        </a>
      </div>
    </div>
  );
};

export default LandingPage;
