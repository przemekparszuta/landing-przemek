
import React from 'react';
import LandingPage from './components/LandingPage';

const App: React.FC = () => {
  return (
    <main>
      <LandingPage />
    </main>
  );
};

export default App;
